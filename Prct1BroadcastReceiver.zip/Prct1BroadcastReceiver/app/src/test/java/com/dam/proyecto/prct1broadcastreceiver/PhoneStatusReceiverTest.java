package com.dam.proyecto.prct1broadcastreceiver;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by dam on 24/01/2018.
 */
public class PhoneStatusReceiverTest {
    @Test
    public void addData() throws Exception {
    }

    @Test
    public void onReceive() throws Exception {
    }

}